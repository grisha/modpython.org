
def test1():
    import test2
    reload(test2)
    msg = test2.s + test2.s2
    msg2 = 'aaa'
    b = test2.proc(msg2)
    #print b

def test2():
    s=open('test2exec.py').read()
    globs = {} ; locs = {}
    exec(s, globs, locs)
    #print locs['b']

def test3():
    globs = {} ; locs = {}
    execfile('test2exec.py', globs, locs)
    #print locs['b']

import time
t=time.time()
for i in range(1000): test1()
print time.time()-t
t=time.time()
for i in range(1000): test2()
print time.time()-t
t=time.time()
for i in range(1000): test3()
print time.time()-t
