
s="""
CatFish version 1.9                     Copyright (C) 1996-1999 Equi4 Software


DESCRIPTION

    CatFish is a disk catalog browser.  It allows you to save snapshots of the
    directory/file structure of your disks and to search through them at any
    time.  The catalog files maintained by CatFish are very compact and fast,
    and can easily handle the huge directory trees often found on large disks,
    removable disks, and CD-ROMs.  CatFish will calculate total subdirectory
    sizes, and lists the date of the newest file found inside each directory.

    You can search all catalogs by file name (wildcards), size, and/or date.
    When used in Win 95/NT, CatFish will recognize and store long file names.
    Furthermore, CatFish can be used as an application or document launcher.

    New in 1.9:  Long catalog names (Win 95/NT), much simpler catalog scans,
                 faster, export partial catalog (and format fixed, asks for
                 a different removable disk if launch of app or doc fails.

    Best of all, CatFish is free.

    For the latest news, check the home page - http://www.equi4.com/catfish/
    Do you have suggestions on how to further improve CatFish?  Let me know!


GETTING STARTED

    Using CatFish is easy, just start it up.  There is no installation, there
    are no DLLs, it runs on all Windows versions (and probably also on OS/2).

    When you start CatFish for the first time, it will give you a few tips.

    When you create catalog files, these will be placed in the same directory
    as CatFish (with a ".CF4" suffix).  If you move CatFish, you must move the
    catalogs as well, otherwise these catalogs will no longer be accessible.
    
    CatFish will create and maintain a catfish.dat, if you ever throw it away,
    it will be re-created automatically (this may take some time).

    To have CatFish open with the "Find" dialog window, start it up using the
    command line "catfish.exe /f" (Win 3.1: program item, Win 95: properties).

    TIP: If you have a very large number of disks, you can group the catalog
    files into several directories and put a copy of CatFish in each of them.


DISTRIBUTION

    The CatFish utility is copyrighted by Equi4 Software.  You may use this
    free software for any purpose, as long as you leave all copyright notices
    in place and assume all risks for its use, regardless of the consequences.
    
    The full C++ source code is freely available, as part of the MetaKit 2.0 
    open source distribution, see http://www.equi4.com/metakit/ for details.


CONTACT INFORMATION

    Equi4 Software                   http://www.equi4.com/
    Jean-Claude Wippler              E-mail: jcw@equi4.com
    Meekrap oord 6                  Phone: +31 30 635 2338
    3991 VE, Houten                   Fax: +31 30 635 2337
    The Netherlands

[Meta Four Software is now called Equi4 Software due to a trade name conflict]

-/-

CatFish version 1.9                     Copyright (C) 1996-1999 Equi4 Software


DESCRIPTION

    CatFish is a disk catalog browser.  It allows you to save snapshots of the
    directory/file structure of your disks and to search through them at any
    time.  The catalog files maintained by CatFish are very compact and fast,
    and can easily handle the huge directory trees often found on large disks,
    removable disks, and CD-ROMs.  CatFish will calculate total subdirectory
    sizes, and lists the date of the newest file found inside each directory.

    You can search all catalogs by file name (wildcards), size, and/or date.
    When used in Win 95/NT, CatFish will recognize and store long file names.
    Furthermore, CatFish can be used as an application or document launcher.

    New in 1.9:  Long catalog names (Win 95/NT), much simpler catalog scans,
                 faster, export partial catalog (and format fixed, asks for
                 a different removable disk if launch of app or doc fails.

    Best of all, CatFish is free.

    For the latest news, check the home page - http://www.equi4.com/catfish/
    Do you have suggestions on how to further improve CatFish?  Let me know!


GETTING STARTED

    Using CatFish is easy, just start it up.  There is no installation, there
    are no DLLs, it runs on all Windows versions (and probably also on OS/2).

    When you start CatFish for the first time, it will give you a few tips.

    When you create catalog files, these will be placed in the same directory
    as CatFish (with a ".CF4" suffix).  If you move CatFish, you must move the
    catalogs as well, otherwise these catalogs will no longer be accessible.
    
    CatFish will create and maintain a catfish.dat, if you ever throw it away,
    it will be re-created automatically (this may take some time).

    To have CatFish open with the "Find" dialog window, start it up using the
    command line "catfish.exe /f" (Win 3.1: program item, Win 95: properties).

    TIP: If you have a very large number of disks, you can group the catalog
    files into several directories and put a copy of CatFish in each of them.


DISTRIBUTION

    The CatFish utility is copyrighted by Equi4 Software.  You may use this
    free software for any purpose, as long as you leave all copyright notices
    in place and assume all risks for its use, regardless of the consequences.
    
    The full C++ source code is freely available, as part of the MetaKit 2.0 
    open source distribution, see http://www.equi4.com/metakit/ for details.


CONTACT INFORMATION

    Equi4 Software                   http://www.equi4.com/
    Jean-Claude Wippler              E-mail: jcw@equi4.com
    Meekrap oord 6                  Phone: +31 30 635 2338
    3991 VE, Houten                   Fax: +31 30 635 2337
    The Netherlands

[Meta Four Software is now called Equi4 Software due to a trade name conflict]

-/-

CatFish version 1.9                     Copyright (C) 1996-1999 Equi4 Software


DESCRIPTION

    CatFish is a disk catalog browser.  It allows you to save snapshots of the
    directory/file structure of your disks and to search through them at any
    time.  The catalog files maintained by CatFish are very compact and fast,
    and can easily handle the huge directory trees often found on large disks,
    removable disks, and CD-ROMs.  CatFish will calculate total subdirectory
    sizes, and lists the date of the newest file found inside each directory.

    You can search all catalogs by file name (wildcards), size, and/or date.
    When used in Win 95/NT, CatFish will recognize and store long file names.
    Furthermore, CatFish can be used as an application or document launcher.

    New in 1.9:  Long catalog names (Win 95/NT), much simpler catalog scans,
                 faster, export partial catalog (and format fixed, asks for
                 a different removable disk if launch of app or doc fails.

    Best of all, CatFish is free.

    For the latest news, check the home page - http://www.equi4.com/catfish/
    Do you have suggestions on how to further improve CatFish?  Let me know!


GETTING STARTED

    Using CatFish is easy, just start it up.  There is no installation, there
    are no DLLs, it runs on all Windows versions (and probably also on OS/2).

    When you start CatFish for the first time, it will give you a few tips.

    When you create catalog files, these will be placed in the same directory
    as CatFish (with a ".CF4" suffix).  If you move CatFish, you must move the
    catalogs as well, otherwise these catalogs will no longer be accessible.
    
    CatFish will create and maintain a catfish.dat, if you ever throw it away,
    it will be re-created automatically (this may take some time).

    To have CatFish open with the "Find" dialog window, start it up using the
    command line "catfish.exe /f" (Win 3.1: program item, Win 95: properties).

    TIP: If you have a very large number of disks, you can group the catalog
    files into several directories and put a copy of CatFish in each of them.


DISTRIBUTION

    The CatFish utility is copyrighted by Equi4 Software.  You may use this
    free software for any purpose, as long as you leave all copyright notices
    in place and assume all risks for its use, regardless of the consequences.
    
    The full C++ source code is freely available, as part of the MetaKit 2.0 
    open source distribution, see http://www.equi4.com/metakit/ for details.


CONTACT INFORMATION

    Equi4 Software                   http://www.equi4.com/
    Jean-Claude Wippler              E-mail: jcw@equi4.com
    Meekrap oord 6                  Phone: +31 30 635 2338
    3991 VE, Houten                   Fax: +31 30 635 2337
    The Netherlands

[Meta Four Software is now called Equi4 Software due to a trade name conflict]

-/-

CatFish version 1.9                     Copyright (C) 1996-1999 Equi4 Software


DESCRIPTION

    CatFish is a disk catalog browser.  It allows you to save snapshots of the
    directory/file structure of your disks and to search through them at any
    time.  The catalog files maintained by CatFish are very compact and fast,
    and can easily handle the huge directory trees often found on large disks,
    removable disks, and CD-ROMs.  CatFish will calculate total subdirectory
    sizes, and lists the date of the newest file found inside each directory.

    You can search all catalogs by file name (wildcards), size, and/or date.
    When used in Win 95/NT, CatFish will recognize and store long file names.
    Furthermore, CatFish can be used as an application or document launcher.

    New in 1.9:  Long catalog names (Win 95/NT), much simpler catalog scans,
                 faster, export partial catalog (and format fixed, asks for
                 a different removable disk if launch of app or doc fails.

    Best of all, CatFish is free.

    For the latest news, check the home page - http://www.equi4.com/catfish/
    Do you have suggestions on how to further improve CatFish?  Let me know!


GETTING STARTED

    Using CatFish is easy, just start it up.  There is no installation, there
    are no DLLs, it runs on all Windows versions (and probably also on OS/2).

    When you start CatFish for the first time, it will give you a few tips.

    When you create catalog files, these will be placed in the same directory
    as CatFish (with a ".CF4" suffix).  If you move CatFish, you must move the
    catalogs as well, otherwise these catalogs will no longer be accessible.
    
    CatFish will create and maintain a catfish.dat, if you ever throw it away,
    it will be re-created automatically (this may take some time).

    To have CatFish open with the "Find" dialog window, start it up using the
    command line "catfish.exe /f" (Win 3.1: program item, Win 95: properties).

    TIP: If you have a very large number of disks, you can group the catalog
    files into several directories and put a copy of CatFish in each of them.


DISTRIBUTION

    The CatFish utility is copyrighted by Equi4 Software.  You may use this
    free software for any purpose, as long as you leave all copyright notices
    in place and assume all risks for its use, regardless of the consequences.
    
    The full C++ source code is freely available, as part of the MetaKit 2.0 
    open source distribution, see http://www.equi4.com/metakit/ for details.


CONTACT INFORMATION

    Equi4 Software                   http://www.equi4.com/
    Jean-Claude Wippler              E-mail: jcw@equi4.com
    Meekrap oord 6                  Phone: +31 30 635 2338
    3991 VE, Houten                   Fax: +31 30 635 2337
    The Netherlands

[Meta Four Software is now called Equi4 Software due to a trade name conflict]

-/-

"""

s2="""
CatFish version 1.9                     Copyright (C) 1996-1999 Equi4 Software


DESCRIPTION

    CatFish is a disk catalog browser.  It allows you to save snapshots of the
    directory/file structure of your disks and to search through them at any
    time.  The catalog files maintained by CatFish are very compact and fast,
    and can easily handle the huge directory trees often found on large disks,
    removable disks, and CD-ROMs.  CatFish will calculate total subdirectory
    sizes, and lists the date of the newest file found inside each directory.

    You can search all catalogs by file name (wildcards), size, and/or date.
    When used in Win 95/NT, CatFish will recognize and store long file names.
    Furthermore, CatFish can be used as an application or document launcher.

    New in 1.9:  Long catalog names (Win 95/NT), much simpler catalog scans,
                 faster, export partial catalog (and format fixed, asks for
                 a different removable disk if launch of app or doc fails.

    Best of all, CatFish is free.

    For the latest news, check the home page - http://www.equi4.com/catfish/
    Do you have suggestions on how to further improve CatFish?  Let me know!


GETTING STARTED

    Using CatFish is easy, just start it up.  There is no installation, there
    are no DLLs, it runs on all Windows versions (and probably also on OS/2).

    When you start CatFish for the first time, it will give you a few tips.

    When you create catalog files, these will be placed in the same directory
    as CatFish (with a ".CF4" suffix).  If you move CatFish, you must move the
    catalogs as well, otherwise these catalogs will no longer be accessible.
    
    CatFish will create and maintain a catfish.dat, if you ever throw it away,
    it will be re-created automatically (this may take some time).

    To have CatFish open with the "Find" dialog window, start it up using the
    command line "catfish.exe /f" (Win 3.1: program item, Win 95: properties).

    TIP: If you have a very large number of disks, you can group the catalog
    files into several directories and put a copy of CatFish in each of them.


DISTRIBUTION

    The CatFish utility is copyrighted by Equi4 Software.  You may use this
    free software for any purpose, as long as you leave all copyright notices
    in place and assume all risks for its use, regardless of the consequences.
    
    The full C++ source code is freely available, as part of the MetaKit 2.0 
    open source distribution, see http://www.equi4.com/metakit/ for details.


CONTACT INFORMATION

    Equi4 Software                   http://www.equi4.com/
    Jean-Claude Wippler              E-mail: jcw@equi4.com
    Meekrap oord 6                  Phone: +31 30 635 2338
    3991 VE, Houten                   Fax: +31 30 635 2337
    The Netherlands

[Meta Four Software is now called Equi4 Software due to a trade name conflict]

-/-

CatFish version 1.9                     Copyright (C) 1996-1999 Equi4 Software


DESCRIPTION

    CatFish is a disk catalog browser.  It allows you to save snapshots of the
    directory/file structure of your disks and to search through them at any
    time.  The catalog files maintained by CatFish are very compact and fast,
    and can easily handle the huge directory trees often found on large disks,
    removable disks, and CD-ROMs.  CatFish will calculate total subdirectory
    sizes, and lists the date of the newest file found inside each directory.

    You can search all catalogs by file name (wildcards), size, and/or date.
    When used in Win 95/NT, CatFish will recognize and store long file names.
    Furthermore, CatFish can be used as an application or document launcher.

    New in 1.9:  Long catalog names (Win 95/NT), much simpler catalog scans,
                 faster, export partial catalog (and format fixed, asks for
                 a different removable disk if launch of app or doc fails.

    Best of all, CatFish is free.

    For the latest news, check the home page - http://www.equi4.com/catfish/
    Do you have suggestions on how to further improve CatFish?  Let me know!


GETTING STARTED

    Using CatFish is easy, just start it up.  There is no installation, there
    are no DLLs, it runs on all Windows versions (and probably also on OS/2).

    When you start CatFish for the first time, it will give you a few tips.

    When you create catalog files, these will be placed in the same directory
    as CatFish (with a ".CF4" suffix).  If you move CatFish, you must move the
    catalogs as well, otherwise these catalogs will no longer be accessible.
    
    CatFish will create and maintain a catfish.dat, if you ever throw it away,
    it will be re-created automatically (this may take some time).

    To have CatFish open with the "Find" dialog window, start it up using the
    command line "catfish.exe /f" (Win 3.1: program item, Win 95: properties).

    TIP: If you have a very large number of disks, you can group the catalog
    files into several directories and put a copy of CatFish in each of them.


DISTRIBUTION

    The CatFish utility is copyrighted by Equi4 Software.  You may use this
    free software for any purpose, as long as you leave all copyright notices
    in place and assume all risks for its use, regardless of the consequences.
    
    The full C++ source code is freely available, as part of the MetaKit 2.0 
    open source distribution, see http://www.equi4.com/metakit/ for details.


CONTACT INFORMATION

    Equi4 Software                   http://www.equi4.com/
    Jean-Claude Wippler              E-mail: jcw@equi4.com
    Meekrap oord 6                  Phone: +31 30 635 2338
    3991 VE, Houten                   Fax: +31 30 635 2337
    The Netherlands

[Meta Four Software is now called Equi4 Software due to a trade name conflict]

-/-

CatFish version 1.9                     Copyright (C) 1996-1999 Equi4 Software


DESCRIPTION

    CatFish is a disk catalog browser.  It allows you to save snapshots of the
    directory/file structure of your disks and to search through them at any
    time.  The catalog files maintained by CatFish are very compact and fast,
    and can easily handle the huge directory trees often found on large disks,
    removable disks, and CD-ROMs.  CatFish will calculate total subdirectory
    sizes, and lists the date of the newest file found inside each directory.

    You can search all catalogs by file name (wildcards), size, and/or date.
    When used in Win 95/NT, CatFish will recognize and store long file names.
    Furthermore, CatFish can be used as an application or document launcher.

    New in 1.9:  Long catalog names (Win 95/NT), much simpler catalog scans,
                 faster, export partial catalog (and format fixed, asks for
                 a different removable disk if launch of app or doc fails.

    Best of all, CatFish is free.

    For the latest news, check the home page - http://www.equi4.com/catfish/
    Do you have suggestions on how to further improve CatFish?  Let me know!


GETTING STARTED

    Using CatFish is easy, just start it up.  There is no installation, there
    are no DLLs, it runs on all Windows versions (and probably also on OS/2).

    When you start CatFish for the first time, it will give you a few tips.

    When you create catalog files, these will be placed in the same directory
    as CatFish (with a ".CF4" suffix).  If you move CatFish, you must move the
    catalogs as well, otherwise these catalogs will no longer be accessible.
    
    CatFish will create and maintain a catfish.dat, if you ever throw it away,
    it will be re-created automatically (this may take some time).

    To have CatFish open with the "Find" dialog window, start it up using the
    command line "catfish.exe /f" (Win 3.1: program item, Win 95: properties).

    TIP: If you have a very large number of disks, you can group the catalog
    files into several directories and put a copy of CatFish in each of them.


DISTRIBUTION

    The CatFish utility is copyrighted by Equi4 Software.  You may use this
    free software for any purpose, as long as you leave all copyright notices
    in place and assume all risks for its use, regardless of the consequences.
    
    The full C++ source code is freely available, as part of the MetaKit 2.0 
    open source distribution, see http://www.equi4.com/metakit/ for details.


CONTACT INFORMATION

    Equi4 Software                   http://www.equi4.com/
    Jean-Claude Wippler              E-mail: jcw@equi4.com
    Meekrap oord 6                  Phone: +31 30 635 2338
    3991 VE, Houten                   Fax: +31 30 635 2337
    The Netherlands

[Meta Four Software is now called Equi4 Software due to a trade name conflict]

-/-

CatFish version 1.9                     Copyright (C) 1996-1999 Equi4 Software


DESCRIPTION

    CatFish is a disk catalog browser.  It allows you to save snapshots of the
    directory/file structure of your disks and to search through them at any
    time.  The catalog files maintained by CatFish are very compact and fast,
    and can easily handle the huge directory trees often found on large disks,
    removable disks, and CD-ROMs.  CatFish will calculate total subdirectory
    sizes, and lists the date of the newest file found inside each directory.

    You can search all catalogs by file name (wildcards), size, and/or date.
    When used in Win 95/NT, CatFish will recognize and store long file names.
    Furthermore, CatFish can be used as an application or document launcher.

    New in 1.9:  Long catalog names (Win 95/NT), much simpler catalog scans,
                 faster, export partial catalog (and format fixed, asks for
                 a different removable disk if launch of app or doc fails.

    Best of all, CatFish is free.

    For the latest news, check the home page - http://www.equi4.com/catfish/
    Do you have suggestions on how to further improve CatFish?  Let me know!


GETTING STARTED

    Using CatFish is easy, just start it up.  There is no installation, there
    are no DLLs, it runs on all Windows versions (and probably also on OS/2).

    When you start CatFish for the first time, it will give you a few tips.

    When you create catalog files, these will be placed in the same directory
    as CatFish (with a ".CF4" suffix).  If you move CatFish, you must move the
    catalogs as well, otherwise these catalogs will no longer be accessible.
    
    CatFish will create and maintain a catfish.dat, if you ever throw it away,
    it will be re-created automatically (this may take some time).

    To have CatFish open with the "Find" dialog window, start it up using the
    command line "catfish.exe /f" (Win 3.1: program item, Win 95: properties).

    TIP: If you have a very large number of disks, you can group the catalog
    files into several directories and put a copy of CatFish in each of them.


DISTRIBUTION

    The CatFish utility is copyrighted by Equi4 Software.  You may use this
    free software for any purpose, as long as you leave all copyright notices
    in place and assume all risks for its use, regardless of the consequences.
    
    The full C++ source code is freely available, as part of the MetaKit 2.0 
    open source distribution, see http://www.equi4.com/metakit/ for details.


CONTACT INFORMATION

    Equi4 Software                   http://www.equi4.com/
    Jean-Claude Wippler              E-mail: jcw@equi4.com
    Meekrap oord 6                  Phone: +31 30 635 2338
    3991 VE, Houten                   Fax: +31 30 635 2337
    The Netherlands

[Meta Four Software is now called Equi4 Software due to a trade name conflict]

-/-

"""

def proc(msg):
    lmsg = msg
    return 2

msg = s + s2
msg2 = 'aaa'
b = proc(msg2)
