# vim: set sw=4 expandtab :

# Code in this file requires mod_python 3.3.

import os
import posixpath

try:
    import threading
except:
    import dummy_threading as threading

from mod_python import apache
from mod_python import Session
from mod_python import util

class SessionManager:

    """Form based user authentication and session manager.

    """

    def __init__(self):
        self.__cache = {}

    def login_page(self, req):
        options = req.get_options()
        page = options.get('session.login_page', 'login.html')
        return page

    def authenticate_user(self, req, username, password):
        return False

    def base_url(self, req):

	# This calculates the base URL corresponding to
	# the directory that the PythonAuthenHandler
	# directive was being used in. Note that the
	# directive must appear within the context of
        # a Directory directive. The login page to be
        # used should be specified relative to this
        # same directory.

        uri = posixpath.normpath(req.uri)

        if uri and uri != '/' and req.uri[-1] == '/':
            uri += '/'
        if req.path_info and len(req.path_info) > 0:
            script_name = uri[:-len(req.path_info)]
        else:
            script_name = uri

        if req.path_info:
            uri = script_name + req.path_info

        length = len(req.filename)
        length -= len(req.hlist.directory) - 1
        length += len(req.path_info or '')

        baseurl = uri[:-length]

        return baseurl

    def _builtin_validate(self, req):

        req.no_cache = 1

        if req.method != 'POST':
            raise apache.SERVER_RETURN, apache.HTTP_BAD_REQUEST

        req.form = util.FieldStorage(req)

        username = req.form.get('username', None)
        password = req.form.get('password', None)

	# Validate that the user has access and if they
	# do not redirect them back to the login page.

        valid = self.authenticate_user(req, username, password)

        if not valid:

            base = self.base_url(req)
            page = posixpath.join(base, self.login_page(req))
            full = req.construct_url(page)

            util.redirect(req, page)

	# Save the username in the session object. This
	# is the trigger for knowing that login was
	# successful in subsequent requests.

        req.session['username'] = username

	# If no 'next' attribute defined in session,
	# assume that location of this method was
	# entered explicitly.

        if not req.session.has_key('next'):

            # Redirect the user to the directory.

            req.session.save()

            base = self.base_url(req)
            full = req.construct_url(base)

            util.redirect(req, base)

	# Retrieve page user originally wanted.

        next = req.session.pop('next')

        # Redirect back to the original page.

        req.session.save()

        full = req.construct_url(next)

        util.redirect(req, next)

    def _builtin_invalidate(self, req):

        req.no_cache = 1

	# Invalidate the session object, thereby
	# effectively logging out the user.

        req.session.invalidate()

	# Redirect the client back to the login page.

        base = self.base_url(req)
        page = posixpath.join(base, self.login_page(req))
        full = req.construct_url(page)

        util.redirect(req, page)

    def __call__(self, req):

	# Only recognise an AuthType directive of 'Session'.

        if req.auth_type().find('Session') == -1:
            return apache.DECLINED

        # Only recognise an AuthName of 'Public' or 'Private'.

        if req.auth_name() not in [ 'Public', 'Private' ]:
            return apache.INTERNAL_SERVER_ERROR

	# Obey protocol of setting 'req.ap_auth_type' to
	# the name identifying the authentication
	# handler used.

        req.ap_auth_type = req.auth_type()

	# Always set 'req.user' to something so that
	# public pages can still be accessed with truly
	# logging in.

        req.user = '<unknown>'

	# Perform the trailing slash redirection that
	# mod_dir module would normally do as last thing
	# in fixup handler phase. This needs to be done
	# before any session created or login required.

        if req.hlist.directory[:-1] == req.filename:
            if req.args:
                util.redirect(req, req.uri+'/?'+req.args)
            else:
                util.redirect(req, req.uri+'/')

	# Lookup up the cache to see if session object
	# has already been created for this request, if
	# not need to create it. Also cache session in
	# the request object for later lookups within
	# context of this request by a later handler.
	# The use of a cache keyed on thread ID outside
	# of the request object is necessary to ensure
	# that any internal redirects and multiple
	# attempts to match against files listed in the
	# DirectoryIndex directive don't cause a
	# deadlock.

        thread = threading.currentThread()

        if self.__cache.has_key(thread):
            req.session = self.__cache[thread]
        else:
            req.session = Session.Session(req)

            self.__cache[thread] = req.session
            def cleanup(data): del self.__cache[thread]
            req.register_cleanup(cleanup)

	# Cache the session ID and whether it is a new
	# session in the environment variables so it
	# might be used by a handler written in another
	# language as a key for its own session based
        # storage.

        req.subprocess_env['SESSION_IS_NEW'] = str(req.session.is_new())
        req.subprocess_env['SESSION_ID'] = req.session.id()

	# Check for requests against builtin operations.
	# The builtin operations are associated with a
	# request against the actual directory the
	# PythonAuthenHandler was used in. Such builtin
	# operations must raise exceptions if they want
	# the status to be immediately returned.

        if req.filename == req.hlist.directory:
            if not req.path_info:
                if req.args:
                    method = '_builtin_%s' % req.args
                    if hasattr(self, method):
                        getattr(self, method)(req)
                    else:
                        return apache.HTTP_BAD_REQUEST

	# If accessing public area nothing more to do.

        if req.auth_name() == 'Public':
            return apache.OK

	# Check that user has been validated and if not
	# redirect them to the login page.

        if not req.session.get('username', None):

            req.session['next'] = req.uri
            req.session.save()

            base = self.base_url(req)
            page = posixpath.join(base, self.login_page(req))
            full = req.construct_url(page)

            util.redirect(req, page)

        # Cache the user name in the request object.

        req.user = req.session.get('username')

	# Mark that any response generated from within
	# the private area should not be cached. If
	# caching is required, then a fixup handler
	# should be registered to reenable caching only
	# where it is required. Alternatively, if files
	# aren't really secret and caching is desired,
        # they should be put in a public area.

        req.no_cache = 1

        return apache.OK


def accesshandler(req):
    if req.finfo and req.finfo[apache.FINFO_FILETYPE] == apache.APR_DIR:

	# If request is against handler directory and
	# there are query args, assume the request is
	# against builtin methods of session manager
        # and don't actually redirect to index file.

        if req.hlist.directory == req.filename:
            if req.args:
                return apache.OK

	# If trailing slash redirection has already been
	# performed redirectory to index page. This is
	# instead of relying on DirectoryIndex directive
	# which has problems in certain circumstances.

        if req.uri[-1] == '/':
            options = req.get_options()
            page = options.get('session.directory_index', 'index.html')
            uri = req.uri + page
            if req.args:
                uri += '?' + req.args
            req.internal_redirect(uri)
            return apache.DONE

        else:

	    # Perform the trailing slash redirection
	    # that mod_dir module would normally do as
	    # last thing in fixup handler phase. This
	    # would also be done by session manager if
	    # the handler directory, but save a few
	    # steps and do it here.

            if req.args:
                util.redirect(req, req.uri+'/?'+req.args)
            else:
                util.redirect(req, req.uri+'/')

    return apache.OK


class ExampleSessionManager(SessionManager):

    def authenticate_user(self, req, username, password):
        return (username == 'mickey') and (password == 'mouse')

authenhandler = ExampleSessionManager()
