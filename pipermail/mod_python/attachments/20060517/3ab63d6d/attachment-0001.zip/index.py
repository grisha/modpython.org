from mod_python import psp, Session, util
import time

def index(req):
	req.content_type = 'text/html'
	tmpl = psp.PSP(req, 'index.tmpl')
	tmpl.run()
	return
	
def check_login(req, name, passwd):
	if (name == 'dan' and passwd == 'cus'):
		sess = Session.Session(req)
		sess['login_name'] = name
		sess['ble'] = 35
		sess.set_timeout(30)
		sess.save()
		s = 'Login successful! :)'
		
	else:
		util.redirect(req, 'http://localhost/templating/')
	
	req.content_type = 'text/html'
	tmpl = psp.PSP(req, 'hello.tmpl')
	tmpl.run({'greet':s})
	return
	
def section(req):
	sess = Session.Session(req)
	sess.load()
	if sess.has_key('ble'):
		s = 'OK' + '    ' + sess['ble'].__str__()
	else:
		util.redirect(req, 'http://localhost/templating/')
		
	req.content_type = 'text/html'
	tmpl = psp.PSP(req, 'hello.tmpl')
	tmpl.run({'greet':s})
	return
	
def logout(req):
	sess = Session.Session(req)
	sess.load()
	sess.invalidate()
	sess.delete()
	util.redirect(req, 'http://localhost/templating/')
