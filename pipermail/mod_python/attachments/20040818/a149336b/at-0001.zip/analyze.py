"""
  Made by 4mix
 http://amix.dk

"""
__access__ = 0

import types
import string

class AnalyzeThatTemplate:
    colors = {"String": "CCFFCC", "Integer": "FFFFCC",
              "Tuple": "CCFFFF", "List": "FFCCCC",
              "Dictionary": "DDDDCC", 
              "Module": "FFCCFF", "Function": "FFCC99",
              "Unknown": "CCCCFF"}
    getColor = lambda self, type: self.colors.get(type)

    swapColors = lambda self, i: (i % 2 == 0 and "ccc") or "999"

    def _renderLayer(self):
        self.html_content = ""
        if self.type in ["String", "Integer", "Boolean"]:
            self.html_content = self.content
        elif self.type in ["List", "Tuple"]:
            self.html_content = self._generateTupListContent()
        elif self.type == "Dictionary":
            self.html_content = self._generateDictionaryContent()
        elif self.type in ["Function", "Module"]:
            self.html_content = self._generateFunctionModuleContent()
        elif self.type == "Unknown":
            self.html_content = self._generateUnknownContent()

        if self.html_content == "":
            self.html_content = "<i>Empty</i>"

        self.header = self._generateHeader()

        layer = """<p><div style="width: 550px; background-color: #%s; padding: 5px; font-size: 13px; font-family: Arial, sans-serif;">\n""" % self.getColor(self.type)
	layer += self.header
	layer += '<div style="font-size: 15px; line-height: 20px;">%s</div></div></p>' % self.html_content

	return layer

    def _generateHeader(self):
        header = "<b>Type: </b>"
        header += '<font style="font-size: 12px;">%s</font>' %\
                self._generateTypeBar()

        header += "\n<br /><br /><b>Content of object</b>"
        header += '<hr style="margin-bottom: 8px; margin-top: 1px;" />\n'
        return header

    def _generateTypeBar(self):
        sort_types = self.colors.keys()
        sort_types.sort()
        color_items = [(k, self.colors[k]) for k in sort_types]

        types_n_colors = [['<font color="#%s">%s</font>' % (v, k), k] \
                          for k, v in color_items]

        getActiveColor = lambda ident: (ident == self.type and "000") or "999"

        with_bg = ['<font style="background-color: #%s">&nbsp;%s&nbsp;</font>' %\
                    (getActiveColor(identifier), html) \
                   for html, identifier in types_n_colors]

        return "&nbsp;".join(with_bg)

    def _generateTupListContent(self):
        list = ['<font style="background-color: #%s;">&nbsp;%i&nbsp;</font> \
                &nbsp;&nbsp;%s' % (self.swapColors(i), i, self.content[i])\
                for i in range(len(self.content))]
        return "<br />".join(list)

    def _generateDictionaryContent(self):
        list = ["<b>%s:</b> <i>%s</i>" % (k,v) for k, v in self.content.items()]
        return "<br />".join(list)

    def _generateFunctionModuleContent(self):
        func_html_info = ['<font color="red">%s</font><br />%s' %\
                          (v[0].upper(), v[1])\
                          for v in self.content]
        return "<p>".join(func_html_info)

    def _generateUnknownContent(self):
        output = str(self.object)
        unknown_type = str(type(self.object))
        for v in ["<", ">"]: unknown_type = unknown_type.replace(v, "")
        output += "<p><b>The object's type</b>: <i>%s</i></p>" % (unknown_type)
        return output


class AnalyzeThatHandlers:

    def _handlerTupleAndList(self):
        return [pair for pair in self.object]
    
    def _handlerFunction(self):
        name = self.object.func_name
        doc = self.object.func_doc
        args_n_defaults = self.__getArguments(self.object)
        func_info = [("Name", name), ("Docstring", doc),
                    ("Arguments and defaults", args_n_defaults)]
        return func_info

    def _handlerModule(self):
        name = self.object.__name__
        doc = self.object.__doc__
        module_methods = self.__getObjectInfo(self.object)
        module_info = [("Name", name), ("Docstring", doc),
                    ("Classes", module_methods)]
        return module_info

    def __getArguments(self, function):
        varnames = []; defaults = []; args = []

        for pos in range(function.func_code.co_argcount):
            varnames.append(function.func_code.co_varnames[pos])

        if function.func_defaults:
            defaults = map(None,function.func_defaults)

        while defaults:
            args.append('<i>%s</i> = %s' % (varnames[-1],repr(defaults[-1])))
            del varnames[-1]
            del defaults[-1]

        while varnames:
            args.append('<b>%s</b>' % varnames[-1])
            del varnames[-1]
        args.reverse()
        return string.joinfields(args, '<br />')
    
    def __getObjectInfo(self, object, spacing=10, collapse=1):
        """From Dive Into Python. I added some HTML.
        TODO: Rewrite - Seperate HTML from code..."""
        methodList = [method for method in dir(object)\
                      if callable(getattr(object, method))]

        processFunc = collapse and (lambda s: " ".join(s.split())) or (lambda s: s)
        with_html = "\n".join(['<tr><td width="220"><b>%s</b></td>\
                               <td width="300">%s</td></tr>' %\
                               (method, processFunc(str(getattr(object, method).__doc__))) \
                               for method in methodList])
        return '<table border="1">%s</table>' % with_html
  

class AnalyzeThat(AnalyzeThatTemplate, AnalyzeThatHandlers):
    supportedTypes = {types.IntType: "Integer", types.StringType: "String",
                      types.TupleType: "Tuple", types.ListType: "List",
                      types.DictType: "Dictionary", 
                      types.ModuleType: "Module", types.FunctionType: "Function"}

    convertToString = lambda self, list, sep="": "%s" % sep.join(list)

    def __init__(self):
	pass

    def analyze ( self, obj ):
        self.object = obj
        self.type = self._setType()

        try:
            if self.type in ["Integer", "String", "Dictionary"]:
                self.content = self.object
            elif self.type in ["Tuple", "List"]:
                self.content = self._handlerTupleAndList()
            else:
                self.content = getattr(self, "_handler%s" % self.type)()

        except AttributeError:
            self.content = str(input)

        return self._renderLayer()

    def _setType(self):
        examine_type = self.convertToString([value for key, value in \
                                             self.supportedTypes.items() \
                                             if key == type(self.object)])
        
        if examine_type == "": return "Unknown"
        else: return examine_type
