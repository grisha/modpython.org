from mod_python import apache

from test import MyError

def handler(req):
    req.write("\ntest")
    
    try:
        #test_handler = apache.import_module('test.handlers.testhandler')
        test_handler = my_import('test.handlers.testhandler')
        val = test_handler.handler(req)
    except MyError, me:
        req.write("\nmyerror")
    except Exception, e:
        req.write("\nexception - %s - %s" % (e.__class__.__name__, e))
    
    return apache.OK
    
def my_import(name):
    mod = __import__(name)
    components = name.split('.')
    for comp in components[1:]:
        mod = getattr(mod, comp)
    return mod