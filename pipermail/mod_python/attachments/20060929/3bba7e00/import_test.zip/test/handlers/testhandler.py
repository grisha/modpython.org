from mod_python import apache

from test import MyError

def handler(req):
    req.write("\ntesthandler - b4 raise")
    
    raise MyError('jk')
    
    req.write("\ntesthandler - af raise")
    return apache.OK