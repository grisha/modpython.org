import os

from mod_python import apache

_root = _here = os.path.dirname(__file__)
_urlstuff = apache.import_module("_urlstuff",path=[_root])

index = _urlstuff.Handler("page1.py/index")
method1 = _urlstuff.Handler("page1.py/method1")
