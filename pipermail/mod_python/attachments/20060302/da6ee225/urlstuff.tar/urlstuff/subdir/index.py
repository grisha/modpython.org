import os

from mod_python import apache

_here = os.path.dirname(__file__)
_root = os.path.join(_here,"..")
_urlstuff = apache.import_module("_urlstuff",path=[_root])

index = _urlstuff.Handler("subdir/index.py/index")
method1 = _urlstuff.Handler("subdir/index.py/method1")
