import posixpath, os

from mod_python import apache

class Handler:
    def __init__(self, name):
        self.__name = name
    def __call__(self, req):
        req.content_type = 'text/plain'
        req.write("object = %s\n" % self.__name)
        req.write("req.filename = %s\n" % req.filename)
        req.write("req.uri = %s\n" % req.uri)
        req.write("req.path_info = %s\n" % req.path_info)
        req.write("req.hlist.directory = %s\n" % req.hlist.directory)
        req.write("\n")
        req.write("original_filename = %s\n" % req.original_filename)
        req.write("normalised_uri = %s\n" % req.normalised_uri)
        req.write("script_name = %s\n" % req.script_name)
        req.write("script_baseurl_abs = %s\n" % req.script_baseurl_abs)
        req.write("script_baseurl_rel = %s\n" % req.script_baseurl_rel)
        req.write("handler_baseurl_abs = %s\n" % req.handler_baseurl_abs)
        req.write("handler_baseurl_rel = %s\n" % req.handler_baseurl_rel)
        req.write("\n")
        req.write("script_login_page_abs = %s\n" %
            posixpath.join(req.script_baseurl_abs, "login.html"))
        req.write("script_login_page_rel = %s\n" %
            posixpath.join(req.script_baseurl_rel, "login.html"))
        req.write("handler_login_page_abs = %s\n" %
            posixpath.join(req.handler_baseurl_abs, "login.html"))
        req.write("handler_login_page_rel = %s\n" %
            posixpath.join(req.handler_baseurl_rel, "login.html"))

def handler(req):

    # Keep a copy of original req.filename as it will
    # be modified by the publisher.

    req.original_filename = req.filename

    # First normalise req.uri when using it as it will
    # preserve repeated slashes in it, whereas such
    # slashes are removed from req.path_info. We must
    # use normalisation function from posixpath and not
    # os.path as Apache always gaurantees to use POSIX
    # format and using os.path version will change
    # slashes to Win32 backslash.

    req.normalised_uri = posixpath.normpath(req.uri)

    # When normalising the path, it will throw away the
    # trailing slash, thus we need to put it back if it
    # appeared in the original.

    if req.normalised_uri:
        if req.normalised_uri != '/' and req.uri[-1] == '/':
            req.normalised_uri += '/'

    # The req.path_info attribute was already normalised
    # above so can simply determine script name by
    # subtracting its length from normalised uri. Note
    # that the script name in this situation can be a
    # directory. In that situation it will have a
    # trailing slash to distinguish it from case whereby
    # script name identifies an actual file.

    if req.path_info:
        req.script_name = req.normalised_uri[:-len(req.path_info)]
    else:
        req.script_name = req.normalised_uri

    # A base url can now be calculated for the directory
    # the script is contained in.

    req.script_baseurl_abs = posixpath.dirname(req.script_name)

    path = req.normalised_uri[len(req.script_baseurl_abs):]
    step = path.count('/') - 1

    if step:
        req.script_baseurl_rel = step * '../'
    else:
        req.script_baseurl_rel = './'

    # A base url can also be calculated corresponding to
    # where the Python*Handler directive was defined.
    # Such a base url can be used in conjunction with a
    # partial path instead of using relative URLs. It
    # can though also be used to help automate the
    # determination of relative URLs. This code will
    # only work if Python*Handler directive appeared in
    # a Directory directive. That is, it will not work
    # if Python*Handler directive appeared inside of a
    # VirtualHost, Location or Files directive. This
    # is because req.hlist.directory will not be set
    # to a useable value in the latter cases. It is
    # also not possible to use this code form inside
    # of mod_python.publisher as it can modify the
    # req.filename attribute, which will stuff this up
    # and the original value will not be available.
    # Finally, also will not work on Win32 for mod_python
    # prior to 3.2.7 as req.hlist.directory has an extra
    # backslash on the path when it shouldn't.

    if req.hlist.directory and os.path.isabs(req.hlist.directory):
        length = len(req.original_filename)
        length -= len(req.hlist.directory) - 1
        length += len(req.path_info or '')

        req.handler_baseurl_abs = req.normalised_uri[:-length]

    else:
        req.handler_baseurl_abs = '/'

    path = req.normalised_uri[len(req.handler_baseurl_abs):]
    step = path.count('/') - 1

    if step:
        req.handler_baseurl_rel = step * '../'
    else:
        req.handler_baseurl_rel = './'

    return apache.OK
